import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vaulthome',
  templateUrl: './vaulthome.page.html',
  styleUrls: ['./vaulthome.page.scss'],
})
export class VaulthomePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
