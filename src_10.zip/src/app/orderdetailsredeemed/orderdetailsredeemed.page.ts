import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orderdetailsredeemed',
  templateUrl: './orderdetailsredeemed.page.html',
  styleUrls: ['./orderdetailsredeemed.page.scss'],
})
export class OrderdetailsredeemedPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
