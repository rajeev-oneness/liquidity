import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outlethomecompare',
  templateUrl: './outlethomecompare.page.html',
  styleUrls: ['./outlethomecompare.page.scss'],
})
export class OutlethomecomparePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
