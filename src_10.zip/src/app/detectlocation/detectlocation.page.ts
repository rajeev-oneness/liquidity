import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detectlocation',
  templateUrl: './detectlocation.page.html',
  styleUrls: ['./detectlocation.page.scss'],
})
export class DetectlocationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
