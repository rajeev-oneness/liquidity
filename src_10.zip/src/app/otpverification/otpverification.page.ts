import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otpverification',
  templateUrl: './otpverification.page.html',
  styleUrls: ['./otpverification.page.scss'],
})
export class OtpverificationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
